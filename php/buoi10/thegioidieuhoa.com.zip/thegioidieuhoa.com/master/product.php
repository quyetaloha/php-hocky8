<div class="product-list">
<div class="row product-row">
    <h2 class="heading">
        <a href="">Điều hòa Sumikura</a>
    </h2>
    <div class="col-md-3 col-lg-3">
        <div class="product-item">
            <a class="product-title" href="">Điều hòa Sumikura 1 chiều APS/APO-092 9.000BTU</a>
            <div class="product-img">
                <a class="img" href="">
                    <img src="https://thegioidieuhoa.com/wp-content/uploads/2018/01/9000btu-1-chieu-aps-apo-092-qRD1Y1-300x200.jpg" alt="">
                </a>
            </div>
            <p class="model">
			    <span class="md"> Model:</span>
			    <strong>APS/APO-092</strong>
            </p>
            <p class="congsuat">
                <span class="cs"> Công suất:
                    9000BTU
                </span>
            </p>
            <p class="price">
		        Giá bán: 4.300.000 VNĐ
            </p>
        </div>
    </div>
    <div class="col-md-3 col-lg-3">
        <div class="product-item">
        <a class="product-title" href="">Điều hòa Sumikura 1 chiều APS/APO-092 9.000BTU</a>
            <div class="product-img">
                <a class="img" href="">
                    <img src="https://thegioidieuhoa.com/wp-content/uploads/2018/01/9000btu-1-chieu-aps-apo-092-qRD1Y1-300x200.jpg" alt="">
                </a>
            </div>
            <p class="model">
			    <span class="md"> Model:</span>
			    <strong>APS/APO-092</strong>
            </p>
            <p class="congsuat">
                <span class="cs"> Công suất:
                    9000BTU
                </span>
            </p>
            <p class="price">
		        Giá bán: 4.300.000 VNĐ
            </p>
        </div>
    </div>
    <div class="col-md-3 col-lg-3">
        <div class="product-item">
        <a class="product-title" href="">Điều hòa Sumikura 1 chiều APS/APO-092 9.000BTU</a>
            <div class="product-img">
                <a class="img" href="">
                    <img src="https://thegioidieuhoa.com/wp-content/uploads/2018/01/9000btu-1-chieu-aps-apo-092-qRD1Y1-300x200.jpg" alt="">
                </a>
            </div>
            <p class="model">
			    <span class="md"> Model:</span>
			    <strong>APS/APO-092</strong>
            </p>
            <p class="congsuat">
                <span class="cs"> Công suất:
                    9000BTU
                </span>
            </p>
            <p class="price">
		        Giá bán: 4.300.000 VNĐ
            </p>
        </div>
    </div>
    <div class="col-md-3 col-lg-3">
        <div class="product-item">
        <a class="product-title" href="">Điều hòa Sumikura 1 chiều APS/APO-092 9.000BTU</a>
            <div class="product-img">
                <a class="img" href="">
                    <img src="https://thegioidieuhoa.com/wp-content/uploads/2018/01/9000btu-1-chieu-aps-apo-092-qRD1Y1-300x200.jpg" alt="">
                </a>
            </div>
            <p class="model">
			    <span class="md"> Model:</span>
			    <strong>APS/APO-092</strong>
            </p>
            <p class="congsuat">
                <span class="cs"> Công suất:
                    9000BTU
                </span>
            </p>
            <p class="price">
		        Giá bán: 4.300.000 VNĐ
            </p>
        </div>
    </div>
</div>
<div class="row product-row">
    <h2 class="heading">
        <a href="">Điều hòa Daikin</a>
    </h2>
    <div class="col-md-3 col-lg-3">
        <div class="product-item">
            <a class="product-title" href="">Điều hòa Daikin 1 chiều FTC25NV1V 9.000BTU</a>
            <div class="product-img">
                <a class="img" href="">
                    <img src="https://thegioidieuhoa.com/wp-content/uploads/2018/01/9000btu-1-chieu-aps-apo-092-qRD1Y1-300x200.jpg" alt="">
                </a>
            </div>
            <p class="model">
			    <span class="md"> Model:</span>
			    <strong>APS/APO-092</strong>
            </p>
            <p class="congsuat">
                <span class="cs"> Công suất:
                    9000BTU
                </span>
            </p>
            <p class="price">
		        Giá bán: 4.300.000 VNĐ
            </p>
        </div>
    </div>
    <div class="col-md-3 col-lg-3">
        <div class="product-item">
        <a class="product-title" href="">Điều hòa Daikin 1 chiều FTC25NV1V 9.000BTU</a>
            <div class="product-img">
                <a class="img" href="">
                    <img src="https://thegioidieuhoa.com/wp-content/uploads/2018/01/9000btu-1-chieu-aps-apo-092-qRD1Y1-300x200.jpg" alt="">
                </a>
            </div>
            <p class="model">
			    <span class="md"> Model:</span>
			    <strong>APS/APO-092</strong>
            </p>
            <p class="congsuat">
                <span class="cs"> Công suất:
                    9000BTU
                </span>
            </p>
            <p class="price">
		        Giá bán: 4.300.000 VNĐ
            </p>
        </div>
    </div>
    <div class="col-md-3 col-lg-3">
        <div class="product-item">
        <a class="product-title" href="">Điều hòa Daikin 1 chiều FTC25NV1V 9.000BTU</a>
            <div class="product-img">
                <a class="img" href="">
                    <img src="https://thegioidieuhoa.com/wp-content/uploads/2018/01/9000btu-1-chieu-aps-apo-092-qRD1Y1-300x200.jpg" alt="">
                </a>
            </div>
            <p class="model">
			    <span class="md"> Model:</span>
			    <strong>APS/APO-092</strong>
            </p>
            <p class="congsuat">
                <span class="cs"> Công suất:
                    9000BTU
                </span>
            </p>
            <p class="price">
		        Giá bán: 4.300.000 VNĐ
            </p>
        </div>
    </div>
    <div class="col-md-3 col-lg-3">
        <div class="product-item">
        <a class="product-title" href="">Điều hòa Daikin 1 chiều FTC25NV1V 9.000BTU</a>
            <div class="product-img">
                <a class="img" href="">
                    <img src="https://thegioidieuhoa.com/wp-content/uploads/2018/01/9000btu-1-chieu-aps-apo-092-qRD1Y1-300x200.jpg" alt="">
                </a>
            </div>
            <p class="model">
			    <span class="md"> Model:</span>
			    <strong>APS/APO-092</strong>
            </p>
            <p class="congsuat">
                <span class="cs"> Công suất:
                    9000BTU
                </span>
            </p>
            <p class="price">
		        Giá bán: 4.300.000 VNĐ
            </p>
        </div>
    </div>
</div>
</div>
