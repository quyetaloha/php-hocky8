<div id="my-carousel" class="carousel slide" data-ride="carousel">
    <!-- <ol class="carousel-indicators">
        <li class="active" data-target="#my-carousel" data-slide-to="0" aria-current="location"></li>
        <li data-target="#my-carousel" data-slide-to="1"></li>
    </ol> -->
    <div class="carousel-inner">
        <div class="carousel-item active">
            <img class="d-block w-100" src="https://thegioidieuhoa.com/wp-content/uploads/2018/05/3844_mua-he-xanh-2018-777x301px-777x287.jpg" alt=""> 
        </div>
        <div class="carousel-item">
            <img class="d-block w-100" src="https://thegioidieuhoa.com/wp-content/uploads/2018/04/timeline-01-01_02-43-24_3334x1459-810x300.png" alt="">
        </div>
        <div class="carousel-item">
            <img class="d-block w-100" src="https://thegioidieuhoa.com/wp-content/uploads/2018/06/Capture-810x300.jpg" alt="">
        </div>
        <div class="carousel-item">
            <img class="d-block w-100" src="https://thegioidieuhoa.com/wp-content/uploads/2018/03/3d814cda926470cc6efdae6710d2bc81-810x300.png" alt="">
        </div>
        <div class="carousel-item">
            <img class="d-block w-100" src="https://thegioidieuhoa.com/wp-content/uploads/2016/12/dieu-hoa-khong-khi-01-21-810x300.jpg" alt="">
        </div>
        <div class="carousel-item">
            <img class="d-block w-100" src="https://thegioidieuhoa.com/wp-content/uploads/2018/05/3844_mua-he-xanh-2018-777x301px-777x287.jpg" alt="">
        </div>
    </div>
    <a class="carousel-control-prev" href="#my-carousel" data-slide="prev" role="button">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#my-carousel" data-slide="next" role="button">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
</div>