<div class="sidebar">
<h2 class="title">
    Điều hòa treo tường
</h2>
<div class="menu-left">
    <ul class="left">
        <li><a href="">Điều hòa LG</a></li>
        <li><a href="">Điều hòa Daikin</a></li>
        <li><a href="">Điều hòa Panasonic</a></li>
        <li><a href="">Điều hòa Sumikura</a></li>
        <li><a href="">Điều hòa Casper</a></li>
        <li><a href="">Điều hòa Midea</a></li>
        <li><a href="">Điều hòa Funiki</a></li>
        <li><a href="">Điều hòa Nagakawa</a></li>
        <li><a href="">Điều hòa Gree</a></li>
        <li><a href="">Điều hòa Fujitsu</a></li>
        <li><a href="">Điều hòa Carrier</a></li>
        <li><a href="">Điều hòa General</a></li>
        <li><a href="">Điều hòa Toshiba</a></li>
        <li><a href="">Điều hòa Samsung</a></li>
        <li><a href="">Điều hòa Galanz</a></li>
        <li><a href="">Điều hòa Mitsubishi Heavy</a></li>
        <li><a href="">Điều hòa Mitsubishi Electric</a></li>
        <li><a href="">Điều hòa chuẩn bị ra mắt</a></li>
        <li><a href="">Bơm nước thải điều hòa</a></li>
    </ul>
</div>
</div>
<div class="bottom-side sidebar">
<h2 class="title">
Điều hòa tủ đứng
</h2>
<div class="menu-left">
    <ul class="left">
        <li><a href="">Điều hòa tủ đứng LG</a></li>
        <li><a href="">Điều hòa tủ đứng Daikin</a></li>
        <li><a href="">Điều hòa tủ đứng Funiki</a></li>
        <li><a href="">Điều hòa tủ đứng Midea</a></li>
        <li><a href="">Điều hòa tủ đứng Nagakawa</a></li>
        <li><a href="">Điều hòa tủ đứng Panasonic</a></li>
        <li><a href="">Điều hòa tủ đứng Sumikura</a></li>
        <li><a href="">Điều hòa tủ đứng Gree</a></li>
        <li><a href="">Điều hòa tủ đứng Casper</a></li>
        <li><a href="">Điều hòa tủ đứng Trane</a></li>
        <li><a href="">Điều hòa tủ đứng Samsung</a></li>
    </ul>
</div>
</div>
<div class="bottom-side sidebar">
<h2 class="title">
Điều hòa âm trần Cassette
</h2>
<div class="menu-left">
    <ul class="left">
        <li><a href="">Điều hòa âm trần LG</a></li>
        <li><a href="">Điều hòa âm trần Daikin</a></li>
        <li><a href="">Điều hòa âm trần Funiki</a></li>
        <li><a href="">Điều hòa âm trần Midea</a></li>
        <li><a href="">Điều hòa âm trần Sumikura</a></li>
        <li><a href="">Điều hòa âm trần Panasonic</a></li>
        <li><a href="">Điều hòa âm trần Nagakawa</a></li>
        <li><a href="">Điều hòa âm trần Fujitsu</a></li>
        <li><a href="">Điều hòa âm trần Gree</a></li>
        <li><a href="">Điều hòa âm trần General</a></li>
        <li><a href="">Điều hòa âm trần Casper</a></li>
        <li><a href="">Điều hòa âm trần Toshiba</a></li>
        <li><a href="">Điều hòa âm trần Carrier</a></li>
        <li><a href="">Điều hòa âm trần Samsung</a></li>
        <li><a href="">Điều hòa âm trần Mitsubishi Heavy</a></li>
        <li><a href="">Điều hòa âm trần Mitsubishi electric</a></li>
    </ul>
</div>
</div>
<div class="bottom-side sidebar">
<h2 class="title">
Điêu hòa ống gió
</h2>
<div class="menu-left">
    <ul class="left">
        <li><a href="">Điều hòa nối ống gió Daikin</a></li>
        <li><a href="">Điều hòa nối ống gió Fujitsu</a></li>
        <li><a href="">Điều hòa nối ống gió Mitsubishi Heavy</a></li>
        <li><a href="">Điều hòa nối ống gió General</a></li>
        <li><a href="">Điều hòa nối ống gió Midea</a></li>
    </ul>
</div>
</div>
<div class="bottom-side sidebar">
<h2 class="title">
Điêu hòa áp trần
</h2>
<div class="menu-left">
    <ul class="left">
        <li><a href="">Điều hòa áp trần Daikin</a></li>
        <li><a href="">Điều hòa áp trần Fujitsu</a></li>
        <li><a href="">Điều hòa áp trần General</a></li>
        <li><a href="">Điều hòa áp trần Panasonic</a></li>
        <li><a href="">Điều hòa áp trần Sumikua</a></li>
    </ul>
</div>
</div>
<div class="bottom-side sidebar">
<h2 class="title">
Điêu hòa multi
</h2>
<div class="menu-left">
    <ul class="left">
        <li><a href="">Điều hòa Multi Daikin</a></li>
        <li><a href="">Điều hòa Multi Fujitsu</a></li>
        <li><a href="">Điều hòa Multi LG</a></li>
        <li><a href="">Điều hòa Multi Mitsubishi Heavy</a></li>
    </ul>
</div>
</div>
<div class="bottom-side sidebar">
<h2 class="title">
Hỗ trợ trực tuyến
</h2>
<div class="menu-left">
    <div id="supporter-info">
        <div id="support-1" class="supporter">
            <div class="info">
                <span class="name">Kinh doanh 1</span><br>
                <span class="phone">0945633233</span>
            </div>
        <div class="online">
        </div>
        </div>
    </div>
        <div id="support-1" class="supporter">
            <div class="info">
                <span class="name">Kinh doanh 2</span><br>
                <span class="phone">0916499299</span>
            </div>
        <div class="online">
        </div>
        </div>
</div>
</div>
<div class="bottom-side sidebar">
<marquee onmouseover="this.stop()" onmouseout="this.start()" scrollamount="3" direction="down" width="100%" height="200" align="center">
    <article class="post-5122 tin-tuc type-tin-tuc status-publish format-standard has-post-thumbnail entry" itemscope="itemscope" itemtype="http://schema.org/CreativeWork"><a href="https://thegioidieuhoa.com/tin-tuc/panasonic-ra-mat-thong-dieu-hoa-nhiet-moi/" title="Panasonic ra mắt hệ thống điều hòa nhiệt độ mới" class="alignleft"><img width="200" height="200" src="https://thegioidieuhoa.com/wp-content/uploads/2016/01/2-jpg-2699-1452152452-200x200.png" class="entry-image attachment-tin-tuc" alt="2-jpg-2699-1452152452" itemprop="image"></a><header class="entry-header"><h2 class="entry-title"><a href="https://thegioidieuhoa.com/tin-tuc/panasonic-ra-mat-thong-dieu-hoa-nhiet-moi/" title="Panasonic ra mắt hệ thống điều hòa nhiệt độ mới">Panasonic ra mắt hệ thống điều hòa nhiệt độ mới</a></h2></header></article>
    <article class="post-5358 tin-tuc type-tin-tuc status-publish format-standard has-post-thumbnail entry" itemscope="itemscope" itemtype="http://schema.org/CreativeWork"><a href="https://thegioidieuhoa.com/tin-tuc/model-moi-may-dieu-hoa-treo-tuong-panasonic-2016/" title="Model mới máy điều hòa treo tường Panasonic 2016" class="alignleft"><img width="200" height="154" src="https://thegioidieuhoa.com/wp-content/uploads/2015/03/dieu-hoa-nhiet-do-panasonic-200x154.jpeg" class="entry-image attachment-tin-tuc" alt="dieu-hoa-nhiet-do-panasonic" itemprop="image"></a><header class="entry-header"><h2 class="entry-title"><a href="https://thegioidieuhoa.com/tin-tuc/model-moi-may-dieu-hoa-treo-tuong-panasonic-2016/" title="Model mới máy điều hòa treo tường Panasonic 2016">Model mới máy điều hòa treo tường Panasonic 2016</a></h2></header></article>
    <article class="post-3364 tin-tuc type-tin-tuc status-publish format-standard has-post-thumbnail entry" itemscope="itemscope" itemtype="http://schema.org/CreativeWork"><a href="https://thegioidieuhoa.com/tin-tuc/ve-sinh-dieu-hoa-nhiet/" title="Cách Vệ sinh điều hòa nhiệt độ" class="alignleft"><img width="200" height="200" src="https://thegioidieuhoa.com/wp-content/uploads/2015/04/821-k2-200x200.jpg" class="entry-image attachment-tin-tuc" alt="821-k2" itemprop="image"></a><header class="entry-header"><h2 class="entry-title"><a href="https://thegioidieuhoa.com/tin-tuc/ve-sinh-dieu-hoa-nhiet/" title="Cách Vệ sinh điều hòa nhiệt độ">Cách Vệ sinh điều hòa nhiệt độ</a></h2></header></article><article class="post-5095 tin-tuc type-tin-tuc status-publish format-standard has-post-thumbnail entry" itemscope="itemscope" itemtype="http://schema.org/CreativeWork"><a href="https://thegioidieuhoa.com/tin-tuc/dieu-hoa-khong-khi-kieu-tran-cassette-3600/" title="Điều hòa không khí kiểu âm trần Cassette 3600" class="alignleft"><img width="200" height="200" src="https://thegioidieuhoa.com/wp-content/uploads/2016/01/untitled-200x200.png" class="entry-image attachment-tin-tuc" alt="untitled" itemprop="image"></a><header class="entry-header"><h2 class="entry-title"><a href="https://thegioidieuhoa.com/tin-tuc/dieu-hoa-khong-khi-kieu-tran-cassette-3600/" title="Điều hòa không khí kiểu âm trần Cassette 3600">Điều hòa không khí kiểu âm trần Cassette 3600</a></h2></header></article>
    <article class="post-4678 tin-tuc type-tin-tuc status-publish format-standard has-post-thumbnail entry" itemscope="itemscope" itemtype="http://schema.org/CreativeWork"><a href="https://thegioidieuhoa.com/tin-tuc/mua-dieu-hoa-panasonic-12000-btu-tai-long-bien/" title="Mua điều hòa Panasonic 12000 BTU tại Long Biên" class="alignleft"><img width="200" height="200" src="https://thegioidieuhoa.com/wp-content/uploads/2015/04/sa-iu-ha-fujitsu-200x200.jpg" class="entry-image attachment-tin-tuc" alt="sa iu ha fujitsu" itemprop="image"></a><header class="entry-header"><h2 class="entry-title"><a href="https://thegioidieuhoa.com/tin-tuc/mua-dieu-hoa-panasonic-12000-btu-tai-long-bien/" title="Mua điều hòa Panasonic 12000 BTU tại Long Biên">Mua điều hòa Panasonic 12000 BTU tại Long Biên</a></li></h2></header></article><article class="post-3371 tin-tuc type-tin-tuc status-publish format-standard has-post-thumbnail entry" itemscope="itemscope" itemtype="http://schema.org/CreativeWork"><a href="https://thegioidieuhoa.com/tin-tuc/dieu-hoa-panasonic-9-000-btu-2-chieu-a9rkh-8-2015/" title="Điều hòa Panasonic 9.000 BTU 2 chiều A9RKH-8 2015" class="alignleft"><img width="200" height="200" src="https://thegioidieuhoa.com/wp-content/uploads/2015/04/1-200x200.png" class="entry-image attachment-tin-tuc" alt="1" itemprop="image"></a><header class="entry-header"><h2 class="entry-title"><a href="https://thegioidieuhoa.com/tin-tuc/dieu-hoa-panasonic-9-000-btu-2-chieu-a9rkh-8-2015/" title="Điều hòa Panasonic 9.000 BTU 2 chiều A9RKH-8 2015">Điều hòa Panasonic 9.000 BTU 2 chiều A9RKH-8 2015</a></h2></header></article><article class="post-3366 tin-tuc type-tin-tuc status-publish format-standard has-post-thumbnail entry" itemscope="itemscope" itemtype="http://schema.org/CreativeWork"><a href="https://thegioidieuhoa.com/tin-tuc/huong-dan-su-dung-dieu-hoa-daikin/" title="Hướng dẫn sử dụng điều hoà Daikin" class="alignleft"><img width="200" height="200" src="https://thegioidieuhoa.com/wp-content/uploads/2015/04/dieu-hoa-_mbyq-200x200.jpg" class="entry-image attachment-tin-tuc" alt="dieu-hoa-_mbyq" itemprop="image"></a><header class="entry-header"><h2 class="entry-title"><a href="https://thegioidieuhoa.com/tin-tuc/huong-dan-su-dung-dieu-hoa-daikin/" title="Hướng dẫn sử dụng điều hoà Daikin">Hướng dẫn sử dụng điều hoà Daikin</a></h2></header></article>
</marquee>
</div>
<div class="bottom-side sidebar">
<h2 class="title">
Thống kê
</h2>
<div class="menu-left">
    <ul class="left">
        <li>Tổng truy cập: <span style="float:right;">286859</span></li>
        <li>Hôm nay:<span style="float:right;">608</span></li>
        <li>Tháng này:<span style="float:right;">2435</span></li>
        <li>Mỗi ngày:<span style="float:right;">594</span></li>
        <li>Đang truy cập:<span style="float:right;">4</span></li>
    </ul>
</div>
</div>
