<div class="row">
                <div class="col-md-3 col-lg-3">
                    <div class="sidebar foot">
                        <h2 class="title">
                        Điêu hòa multi
                        </h2>
                        <div class="menu-left">
                            <ul class="left">
                                <li><a href="">Điều hòa Multi Daikin</a></li>
                                <li><a href="">Điều hòa Daikin</a></li>
                                <li><a href="">Điều hòa Mitsubishi Electric</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-lg-3">
                    <div class="sidebar foot">
                        <h2 class="title">
                        Điêu hòa multi
                        </h2>
                        <div class="menu-left">
                            <ul class="left">
                                <li><a href="">Điều hòa LG</a></li>
                                <li><a href="">Điều hòa Midea</a></li>
                                <li><a href="">Điều hòa Nagakawa</a></li>
                                <li><a href="">Điều hòa Samsung</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-lg-3">
                    <div class="sidebar foot">
                        <h2 class="title">
                        Điêu hòa multi
                        </h2>
                        <div class="menu-left">
                            <ul class="left">
                                <li><a href="">Điều hòa Daikin</a></li>
                                <li><a href="">Điều hòa Fujitsu</a></li>
                                <li><a href="">Điều hòa Panasonic</a></li>
                                <li><a href="">Điều hòa Carrier</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-lg-3">
                    <div class="sidebar foot">
                        <h2 class="title">
                        Điêu hòa multi
                        </h2>
                        <div class="menu-left">
                            <ul class="left">
                                <li><a href="">Điều hòa Daikin</a></li>
                                <li><a href="">Điều hòa Panasonic</a></li>
                                <li><a href="">Điều hòa Mitsubishi Electric</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
