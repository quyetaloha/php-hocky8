<div class="lostlist">
    <div class="header" style="margin-bottom: 30px;">
        <h6 class="header-pretitle">Tổng quan</h6>
        <h1 class="title">
            Danh sách sản phẩm
        </h1>
    </div>
    <div style="border-bottom:1px solid grey;">
        <p class="method" style="">General</p>
    </div>

    <div class="card">
        <div class="card-header">
            <div class="row justify-content-center">
                <div class="col-12 col-md-12 col-lg-12">
                  
                    <div class="card-body row no-gutters ">
                        <div class="col">
                            <input name="search" type="search" class="form-control form-control-flush search" placeholder="Search by name...">                            
                        </div>
                        <div class="col-auto">
                            <button type="submit" class="btn btn-outline-primary"><i class="fas fa-search"></i></button>
                        </div>
                    </div>
                   
                </div>
            </div>
            <!-- / .row -->
        </div>
        
        <table class="table table-sm card-table">
            <thead class="thead">
                <tr>
                    <th></th>
                    <th>Ảnh</th>
                    <th>Tên</th>
                    <th>Trạng thái</th>
                    <th>Giá tiền</th>
                   
                </tr>
            </thead>
            <tbody>

     

                <tr>
                    <td style="padding-top: 40px;"><input type="checkbox" name="deletePro[]" value=""></td>
                    <td scope="row"><img width="100px" height="100px" src="https://www.prodirectsoccer.com/productimages/V3_1_Main/195610_Main_Thumb_0369993.jpg"
                            alt=""></td>
                    <td class="text">
                        <a href=""></a>
                    </td>
                    <td class="text">

                    </td>
                    <td class="text">

                    </td>
                    
                </tr>

            </tbody>
        </table>
        <div class="card-footer">
            <button type="submit" class="btn btn-outline-danger" style="width:50px;"><i class="fas fa-trash-alt"></i></button>
        </div>
        
    </div>



</div>